import requests 

X = [[ 110, 3, 0]]

response = requests.post("http://localhost:5000/predict", json={"X": X})


print(response.json())