from fastapi import FastAPI
from pydantic import BaseModel

class Features(BaseModel):
    X: list
    

app = FastAPI()

@app.post("/predict")
async def create_item(item: Features):
    return {"y_pred": [2]}