from typing import Optional

from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()


class Features(BaseModel):
    X: list[list[float]]

    

@app.get("/")
def read_root():
    return {"Hello": "World"}



@app.post("/predict")
def predict(item: Features):
    
    
    print(item.x)