from flask import Flask, request #request représente la requête entrante
import json 

import joblib 

model = joblib.load("regression.joblib")

app = Flask(__name__)

@app.route("/predict")#permet de spécifier quand la fonction juste en dessous doit être appelée
def hello_world():

    #ça suppose que le client envoie une requête avec dedans X
    X = request.json['X']
    print(X)
    ## récupérer les données envoyées par le client (X)
    y_pred = model.predict(X)
    response = {
        'prediction': y_pred
    }
    return json.dumps(response)


if __name__ == "__main__":

    app.run(debug=True)